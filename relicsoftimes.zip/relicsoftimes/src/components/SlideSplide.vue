<template>
  <div class="slider-wrapper">
    <Splide :options="options">
      <SplideSlide v-for="(slide, index) in slides" :key="index">
        <img :src="slide.src" :alt="slide.alt" />
      </SplideSlide>
    </Splide>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Splide, SplideSlide } from '@splidejs/vue-splide'
import '@splidejs/splide/dist/css/splide.min.css'

const options = {
  type: 'loop',
  perPage: 3,
  perMove: 1,
  autoplay: true,
  interval: 3000,
  pauseOnHover: false,
  arrows: false,
  pagination: false,
  gap: '1rem',
  breakpoints: {
    1024: {
      perPage: 2,
    },
    640: {
      perPage: 1,
    },
  },
}

const slides = ref([
  { src: new URL('../assets/photodesgolmont.png', import.meta.url).href, alt: 'Image 1' },
  { src: new URL('../assets/image2.png', import.meta.url).href, alt: 'Image 2' },
  { src: new URL('../assets/image3.png', import.meta.url).href, alt: 'Image 3' },
  { src: new URL('../assets/image4.png', import.meta.url).href, alt: 'Image 4' },
  { src: new URL('../assets/image5.png', import.meta.url).href, alt: 'Image 5' },
])
</script>

<style scoped>
.slider-wrapper {
  width: 90vw;
  margin: 0 auto;
  border: 2px dashed red; /* debug */
}

img {
  width: 100%;
  height: 250px; /* ou auto + min-height si besoin */
  object-fit: cover;
  border-radius: 10px;
}

</style>
