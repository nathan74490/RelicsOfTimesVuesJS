<template>
  <Splide :options="options">
    <SplideSlide>
      <img src="https://picsum.photos/800/400?random=1" alt="Test 1" />
    </SplideSlide>
    <SplideSlide>
      <img src="https://picsum.photos/800/400?random=2" alt="Test 2" />
    </SplideSlide>
  </Splide>
</template>

<script setup>
import { ref } from 'vue'
import { Splide, SplideSlide } from '@splidejs/vue-splide'
import '@splidejs/splide/dist/css/splide.min.css'

const options = {
  type: 'loop',
  perPage: 1,
  autoplay: true,
  interval: 3000,
  pauseOnHover: true,
  arrows: true,
  pagination: true,
}

const slides = ref([
  {
    src: 'https://via.placeholder.com/800x400/3498db/ffffff?text=Slide+1',
    alt: 'Image 1',
  },
  {
    src: 'https://via.placeholder.com/800x400/e74c3c/ffffff?text=Slide+2',
    alt: 'Image 2',
  },
  {
    src: 'https://via.placeholder.com/800x400/2ecc71/ffffff?text=Slide+3',
    alt: 'Image 3',
  },
])
</script>

<style scoped>
.splide {
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
}

.splide__slide {
  height: 400px; /* force la hauteur pour qu'on voie le slide */
}

img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
border: 4px solid red;
}
</style>

