<script setup>
import Homepage from '../components/home.vue'
</script>

<template>
  <main>
    <Homepage />
  </main>
</template>
