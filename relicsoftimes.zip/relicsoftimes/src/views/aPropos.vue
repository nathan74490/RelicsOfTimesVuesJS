<template>
    <h1>page a propos</h1>
</template>